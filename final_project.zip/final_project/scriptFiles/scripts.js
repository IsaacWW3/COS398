/*
* Var clicker and var upgrade are both any because when using
* string or number both gave errors, i think this is due to
* it getting the element by the ID which is not a string or
* number
*/
var clicker = document.getElementById("clicker"), count = 0, num = 1;
clicker.onclick = function () {
    count += num;
    clicker.innerHTML = "Cookies: " + count;
};
var upgrade = document.getElementById("upgrade");
upgrade.onclick = function () {
    if (count >= 20) {
        num += 1;
        count -= 20;
        clicker.innerHTML = "Cookies: " + count;
    }
    upgrade.innerHTML = "Upgrade (20 cookies): " + num;
};
var time_upgrade = document.getElementById("sec");
time_upgrade.onclick = function () {
    //let seconds:number = 0;
    if (count >= 100) {
        time_upgrade.style.display = "none";
        count -= 100;
        clicker.innerHTML = "Cookies: " + count;
        var timer = setInterval(function () {
            count++;
            //console.log(count);
            clicker.innerHTML = "Cookies: " + count;
            // if (seconds = 10){
            //     clearInterval(timer);
            //     console.log('Time has hit 10')
            // }
        }, 1000);
    }
};
